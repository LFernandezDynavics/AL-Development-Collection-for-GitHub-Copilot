# ALDC Core Specification v1.1

## Estado

- Versión: 1.1.0
- Fecha: 2026-03-01
- Alcance: repositorios AL (Business Central) que adopten ALDC Core como backbone operativo.
- Cambio respecto a v1.0: simplificación skills-based, contratos por requerimiento, memory global.

## Lenguaje normativo

Las palabras **MUST**, **SHOULD**, **MAY** y sus negaciones se interpretan como requisitos normativos.

## Objetivo

ALDC Core define el mínimo común verificable para convertir el trabajo con agentes en un flujo:
- repetible (siempre los mismos artefactos y gates),
- auditable (decisiones y cambios rastreables),
- gobernable (con validación automática y HITL).

ALDC Core está diseñado para el enfoque:

**spec.create → al-architect → especificación técnica → al-conductor (planning-subagent, al-developer, review-subagent) → gates HITL → entrega**

## Definiciones

- **Toolkit**: conjunto de agentes / instrucciones / prompts / skills instalados en el repo.
- **toolkitRoot**: ruta raíz del toolkit en el repo (configurable en `aldc.yaml`).
- **Plans folder**: carpeta canónica para contratos compartidos: `.github/plans/`.
- **Entrypoint de Copilot**: fichero repo-wide que Copilot lee por convención: `.github/copilot-instructions.md`.
- **Skill**: módulo de conocimiento composable que agentes cargan bajo demanda. Vive en `skills/` bajo `toolkitRoot`.
- **Requirement set**: conjunto de 3 artefactos contractuales por requerimiento (`{req_name}.spec.md`, `{req_name}.architecture.md`, `{req_name}.test-plan.md`).
- **Memory global**: fichero único acumulativo (`.github/plans/memory.md`) que registra decisiones transversales, contexto inter-sesión y estado del proyecto.
- **Template**: fichero inmutable en `docs/templates/`, solo modificable por maintainer vía RFC.

## Estructura de repositorio obligatoria

Un repositorio ALDC Core **MUST** contener:

- `aldc.yaml` en la raíz.
- `.github/plans/` con:
  - `memory.md` global obligatorio
  - Requirement sets: `{req_name}.spec.md`, `{req_name}.architecture.md`, `{req_name}.test-plan.md` por cada requerimiento activo
- Un entrypoint repo-wide de Copilot en `.github/copilot-instructions.md`.
- Un toolkit (en `toolkitRoot`) con:
  - `agents/` (agentes invocables por el usuario)
  - `agents/orchestra/` (subagents internos del conductor, `user-invokable: false`)
  - `instructions/`
  - `prompts/`
  - `skills/` (módulos de conocimiento composables)
  - `docs/templates/` (plantillas inmutables)

Nota: `toolkitRoot` **MAY** ser `.` en repos de framework y `.github` en repos consumidores.

## Agentes Core requeridos

ALDC Core v1.1 adopta un modelo simplificado de **4 agentes públicos + 2 subagents internos**.

### Agentes públicos (`user-invokable: true`)

- **al-architect** — Diseño, arquitectura, decisiones estratégicas. Carga skills según dominio (API, Copilot, performance).
- **al-conductor** — Orquestador TDD principal. Coordina subagents via `runSubagent`. Ciclo: Plan → Implement → Review → Commit.
- **al-developer** — Implementación táctica + debugging. Carga skills según tarea (debug, events, permissions, etc.). También invocable como subagent por el conductor.
- **al-presales** — Estimación y planificación de proyectos. Vive fuera del ciclo de desarrollo.

### Subagents internos (`user-invokable: false`, en `agents/orchestra/`)

- **al-planning-subagent** — Research AL-aware y context gathering. Devuelve findings estructurados al conductor.
- **al-review-subagent** — Code review contra spec + architecture + test-plan. Devuelve veredicto APPROVED/NEEDS_REVISION/FAILED.

### Flujo de orquestación del conductor

```
al-conductor (orquestador)
  ├── runSubagent → al-planning-subagent (research, devuelve findings)
  ├── runSubagent → al-developer (implementa fase TDD, devuelve resultado)
  └── runSubagent → al-review-subagent (review, devuelve veredicto)
```

Frontmatter del conductor:
```yaml
tools: ['runSubagent', ...]
agents: ['al-planning-subagent', 'al-review-subagent', 'al-developer']
```

Nota: `al-developer` es dual — invocable directamente por el usuario y también como subagent del conductor.

### Agentes eliminados respecto a v1.0

Los siguientes agentes se absorben en el modelo simplificado:

| Eliminado | Absorbido en |
|-----------|-------------|
| `al-debugger` | `al-developer` + `skill-debug` |
| `al-tester` | `al-conductor` (TDD inherente) + `skill-testing` |
| `al-api` | `al-architect` + `skill-api` (diseño) / `al-developer` + `skill-api` (impl) |
| `al-copilot` | `al-architect` + `skill-copilot` (diseño) / `al-developer` + `skill-copilot` (impl) |
| `al-implement-subagent` | `al-developer` (invocado como subagent por conductor) |

## Workflows Core requeridos

Para ejecutar el flujo Core, el toolkit **MUST** incluir:

- **al-spec.create** — Normalizar requerimientos → `{req_name}.spec.md`
- **al-build** — Verificación/compilación/packaging
- **al-pr-prepare** — Documentación y entrega en PR
- **al-context.create** — Generar/actualizar contexto del proyecto
- **al-memory.create** — Actualizar `memory.md` global
- **al-initialize** — Setup inicial del entorno (baja frecuencia)

### Workflows eliminados respecto a v1.0

| Eliminado | Absorbido en |
|-----------|-------------|
| `al-diagnose` | `al-developer` + `skill-debug` |
| `al-events` (prompt) | `skill-events` |
| `al-performance` + `al-performance.triage` | `skill-performance` |
| `al-permissions` | `skill-permissions` |
| `al-migrate` | `skill-migrate` |
| `al-pages` | `skill-pages` |
| `al-translate` | `skill-translate` |
| `al-copilot-capability` | `skill-copilot` (fase 1) |
| `al-copilot-promptdialog` | `skill-copilot` (fase 2) |
| `al-copilot-generate` | `skill-copilot` (fase 3) |
| `al-copilot-test` | `skill-copilot` (fase 4) |

## Skills Core

### Definición

Un **skill** es un módulo de conocimiento composable en formato markdown que reside en `skills/` bajo `toolkitRoot`. Los agentes cargan skills bajo demanda según el contexto de la tarea.

### Características

- Los skills **MUST NOT** tener frontmatter de agente (no son invocables directamente).
- Los skills **MUST** ser autocontenidos: incluyen patrones, ejemplos, workflows y referencias.
- Los skills **SHOULD** mantenerse bajo 500 líneas para optimizar context window.
- Los skills **MUST** seguir la convención de nombre `skill-{domain}.md`.

### Skills Core requeridos

El toolkit **MUST** incluir estos skills mínimos para cubrir las capacidades absorbidas:

| Skill | Contenido | Cargado por |
|-------|-----------|-------------|
| `skill-api.md` | API design, OData/REST, versionado, BC API pages | architect (diseño), developer (impl) |
| `skill-copilot.md` | Copilot capability, PromptDialog, AI generation, AI testing — lifecycle completo | architect (diseño), developer (impl) |
| `skill-debug.md` | Debugging workflow, snapshot, CPU profiling, root cause analysis | developer |
| `skill-performance.md` | Profiling, triage, SetLoadFields, FlowField, perf patterns | architect (análisis), developer (fix) |
| `skill-events.md` | Event discovery, subscriber/publisher patterns, event recorder | developer, architect |
| `skill-permissions.md` | Permission set generation, security patterns, least-privilege | developer |
| `skill-testing.md` | Test strategy design, Given/When/Then, AI Test Toolkit | conductor (strategy), developer (impl) |

### Skills recomendados (SHOULD)

| Skill | Contenido | Cargado por |
|-------|-----------|-------------|
| `skill-migrate.md` | Version migration, breaking changes, rollback | developer |
| `skill-pages.md` | Page Designer, page types, UX patterns | developer |
| `skill-translate.md` | XLF workflow, NAB tools, multi-language | developer |
| `skill-estimation.md` | Cost models, SWOT, project structure | presales |

### Mecanismo de carga

En GitHub Copilot, los agentes referencian skills condicionalmente:

```markdown
## Domain Skills

When the task involves API design or implementation, load and follow:
- @file skills/skill-api.md

When debugging is needed, load and follow:
- @file skills/skill-debug.md
```

### Creación de nuevos skills

Los skills siguen la plantilla `docs/templates/skill-template.md`. Cualquier contributor **MAY** proponer nuevos skills via PR. Skills que alteren el comportamiento Core **MUST** seguir el proceso RFC.

## Instructions (sin cambios)

Las 9 instructions files se mantienen sin cambios. Son reglas pasivas auto-aplicadas por `applyTo` patterns:

- `al-guidelines.instructions.md` — Master hub (`**/*.{al,json}`)
- `al-code-style.instructions.md` — Code formatting (`**/*.al`)
- `al-naming-conventions.instructions.md` — Naming rules (`**/*.al`)
- `al-performance.instructions.md` — Performance patterns (`**/*.al`)
- `al-error-handling.instructions.md` — Error handling (`**/*.al`)
- `al-events.instructions.md` — Event patterns (`**/*.al`)
- `al-testing.instructions.md` — Testing rules (`**/test/**/*.al`)
- `copilot-instructions.md` — Master coordination (repo-wide)
- `index.md` — Catalog

## Contratos por requerimiento en `.github/plans/`

### Estructura

```
.github/plans/
  memory.md                              ← GLOBAL (único, acumulativo)
  {req_name}.spec.md                     ← por requerimiento
  {req_name}.architecture.md             ← por requerimiento
  {req_name}.test-plan.md                ← por requerimiento
  archive/                               ← requerimientos completados
```

### Convención de nombres

- `{req_name}` **MUST** ser kebab-case (ej: `customer-discount`, `api-integration`)
- `{req_name}` **MUST** ser consistente en los 3 ficheros del set
- Los tipos son: `spec`, `architecture`, `test-plan`
- El patrón completo es: `{req_name}.{type}.md`

### Contrato `{req_name}.spec.md`

**MUST** contener:
- Contexto y objetivo
- Alcance / no alcance
- Requisitos normalizados (R1…Rn)
- Criterios de aceptación (AC-F, AC-T, AC-Q)
- Restricciones (incl. extensión-only)
- Especificación técnica (MUST para MEDIUM/HIGH)

### Contrato `{req_name}.architecture.md`

**MUST** contener:
- Diseño de alto nivel
- Mapa de objetos AL
- Arquitectura de eventos
- Seguridad/permisos
- Rendimiento
- Decisiones (rationale + alternativas)

### Contrato `{req_name}.test-plan.md`

**MUST** contener:
- Estrategia de test
- Matriz de escenarios (Given/When/Then)
- Datos de prueba
- Quality gates

### Memory global (`memory.md`)

Fichero único y acumulativo. **MUST NOT** borrarse ni sobrescribirse.

**MUST** contener:
- Estado actual del proyecto
- Requerimientos activos (tabla)
- Decisiones tomadas (transversales y por requerimiento)
- Cambios de alcance
- Lecciones aprendidas
- Contexto inter-sesión
- Próximos pasos

Los agentes y humanos **SHOULD** actualizar `memory.md` en cada handoff significativo.

### Flujo de creación de artefactos

1. Asignar `{req_name}` (kebab-case)
2. `al-spec.create`: COPIAR `spec-template.md` → `{req_name}.spec.md`, rellenar
3. `al-architect`: COPIAR `architecture-template.md` → `{req_name}.architecture.md`, rellenar
4. Crear `{req_name}.test-plan.md` desde template
5. Actualizar `memory.md` global con contexto del nuevo requerimiento
6. `al-conductor` ejecuta referenciando los 3 artefactos + `memory.md`
7. Gates HITL por fase
8. Entrega → actualizar `memory.md` con resultado
9. Archivar set completado en `archive/` (opcional)

## Templates inmutables

Los templates viven en `docs/templates/` y **MUST NOT** ser modificados por agentes/workflows. Solo el maintainer puede modificarlos vía RFC.

Templates requeridos (7):
- `spec-template.md`
- `architecture-template.md`
- `test-plan-template.md`
- `memory-template.md` (para inicializar memory global)
- `technical-spec-template.md`
- `delivery-template.md`
- `skill-template.md` (NUEVO en v1.1)

Los agentes **MUST** copiar template → rellenar → escribir en plans (nunca editar template directamente).

## Principios Core

El repositorio y los agentes **MUST** operar respetando:

- **Extensión-only**: **MUST NOT** modificar objetos base directamente.
- **Event-driven**: **SHOULD** usar subscribers/publishers.
- **Spec-driven**: **MUST** existir contrato de comportamiento antes de implementar.
- **Architecture-first** (MEDIUM/HIGH): **MUST** existir `{req_name}.architecture.md` aprobado.
- **HITL**: el humano sigue siendo decisor; gates obligatorios.
- **TDD**: en MEDIUM/HIGH, **SHOULD** aplicarse RED → GREEN → REFACTOR.
- **Immutable templates**: templates solo modificables por maintainer vía RFC.
- **Global memory**: `memory.md` es acumulativo, nunca se borra.
- **Skills-based**: capacidades especializadas se encapsulan en skills composables.

## Gates HITL (obligatorios)

- **Gate de complejidad**: sistema **MUST** esperar confirmación humana antes de rutear.
- **Gate de arquitectura** (MEDIUM/HIGH): `{req_name}.architecture.md` **MUST** ser aprobado.
- **Gate por fase** (MEDIUM/HIGH): `al-conductor` **MUST** solicitar validación humana.
- **Gate de review**: implementación **MUST** pasar revisión contra spec + architecture + test-plan.
- **Gate de entrega**: **MUST** entregar sin errores conocidos + documentación actualizada.

## Criterios de conformidad (ALDC Core v1.1 Compliant)

Un repositorio es **ALDC Core v1.1 compliant** si:

1. Existe `aldc.yaml` válido contra el schema.
2. Existe `.github/plans/memory.md` (global).
3. Cada requerimiento activo tiene set completo: `{req_name}.spec.md`, `.architecture.md`, `.test-plan.md`.
4. Las 7 plantillas inmutables existen en `docs/templates/` sin alteración.
5. Los 4 agentes Core + 2 subagents internos existen bajo `toolkitRoot`.
6. Los 6 workflows Core existen bajo `toolkitRoot`.
7. Los 7 skills Core requeridos existen en `skills/`.
8. Las 9 instructions existen.
9. El entrypoint `.github/copilot-instructions.md` es coherente.
10. En MEDIUM/HIGH: flujo spec → architecture → conductor(subagents) → review → entrega con gates HITL.

## Extensibilidad

Extensiones **MAY** añadir:
- Skills adicionales por dominio.
- Agentes especializados (como extensiones, no Core).
- Workflows adicionales.

Pero **MUST NOT**:
- Romper contratos de `.github/plans/`.
- Redefinir nombres de agentes/workflows/skills Core.
- Debilitar gates o reglas de extensión-only.
- Modificar plantillas inmutables.
- Borrar o sobrescribir contenido de `memory.md`.

## Resumen de primitives v1.1

| Tipo | Cantidad | Detalles |
|------|----------|---------|
| Agentes públicos | 4 | architect, conductor, developer, presales |
| Subagents internos | 2 | planning-subagent, review-subagent |
| Workflows | 6 | spec.create, build, pr-prepare, memory.create, context.create, initialize |
| Skills requeridos | 7 | api, copilot, debug, performance, events, permissions, testing |
| Skills recomendados | 4 | migrate, pages, translate, estimation |
| Instructions | 9 | Sin cambios |
| Templates | 7 | +1 skill-template.md |
| **Total** | **39** | (vs 38 en v1.0, pero con mucha menor complejidad cognitiva) |
